﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonSelectImages_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialogImage.ShowDialog();
            if (result == DialogResult.OK)
            {
                buttonReformatImages.Enabled = true;
                progressBarReformat.Value = 0;
                progressBarReformat.Visible = true;
            }
            else
            {
                buttonReformatImages.Enabled = false;
            }
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonReformatImages_Click(object sender, EventArgs e)
        {
            progressBarReformat.Value = 0;
            for (int Index = 0; Index < openFileDialogImage.FileNames.Count(); Index++)
                {
                    if (openFileDialogImage.FileNames[Index].Contains("_Reformatted_") == false)
                    {
                        Image ImageOriginal = Image.FromFile(openFileDialogImage.FileNames[Index]);
                        using (var BitmapNew = new Bitmap(ImageOriginal.Width - 520,ImageOriginal.Height))
                        {
                            using (var Canvas = Graphics.FromImage(BitmapNew))
                            {
                                Canvas.DrawImage(ImageOriginal, new Rectangle(    0, 0,  250, ImageOriginal.Height),
                                                                new Rectangle(    0, 0,  250, ImageOriginal.Height), GraphicsUnit.Pixel);
                                Canvas.DrawImage(ImageOriginal, new Rectangle(  250, 0,  370, ImageOriginal.Height),
                                                                new Rectangle(  350, 0,  370, ImageOriginal.Height), GraphicsUnit.Pixel);
                                Canvas.DrawImage(ImageOriginal, new Rectangle(  620, 0, ImageOriginal.Width - 1140, ImageOriginal.Height),
                                                                new Rectangle( 1140, 0, ImageOriginal.Width - 1140, ImageOriginal.Height), GraphicsUnit.Pixel);
                                Canvas.Save();
                            }
                            int TestIndex = 0;
                            for (TestIndex = openFileDialogImage.FileNames[Index].Length - 1; TestIndex > -1; TestIndex --)
                            {
                                if (openFileDialogImage.FileNames[Index].Substring(TestIndex, 1) == "\\")
                                    break;
                            }
                            if (TestIndex > 0)
                                TestIndex ++;
                            try
                            {
                                BitmapNew.Save(openFileDialogImage.FileNames[Index].Substring(0,TestIndex) + "_Reformatted_" + 
                                               openFileDialogImage.FileNames[Index].Substring(TestIndex,openFileDialogImage.FileNames[Index].Length - TestIndex),
                                               ImageFormat.Jpeg);
                            }
                            catch
                            {
                                MessageBox.Show("Failed to save reformatted image " + openFileDialogImage.FileNames[Index] + " to disk.");
                                BitmapNew.Dispose();
                                break;
                            }
                            BitmapNew.Dispose();
                        }
                        ImageOriginal.Dispose();
                        progressBarReformat.Value = 100 * (Index / openFileDialogImage.FileNames.Count());
                    }
                }
            progressBarReformat.Value = 100;
            MessageBox.Show("Image Reformatting Complete");
        }       
    }
}
